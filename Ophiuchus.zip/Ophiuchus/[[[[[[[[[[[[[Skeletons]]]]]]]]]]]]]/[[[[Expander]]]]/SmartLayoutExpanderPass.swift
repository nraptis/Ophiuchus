//
//  SmartLayoutExpanderPass.swift
//  Ophiuchus
//
//  Created by Nick on 8/11/25.
//

import Foundation

struct SmartLayoutExpanderPass {
    
    public static func pass(groupData: SkeletonLayoutGroupDataExploded,
                            layoutPriority: LayoutPriority) {
        SmartLayoutExpanderPass.prepare_intelligent(groupData: groupData, layoutPriority: layoutPriority)
        var max_loops = 1000
        var fudge = 0
        while fudge < max_loops {
            if fudge == 12 {
                print("slkfskldf")
            }
            print("LOOP NUMBER: \(fudge)")
            if SmartLayoutExpanderPulse.pulse() {
                fudge += 1
            } else {
                break
            }
        }
        if fudge == max_loops {
            fatalError("TODO: Remove. We got stuck on a loop...")
        }
        print("The Loop @ \(layoutPriority) Ran \(fudge) times!!!")
    }
    
    public static func prepare_naive(groupData: SkeletonLayoutGroupDataExploded,
                                     layoutPriority: LayoutPriority) {
        
        groupData.calculateFlexerTargetSizeCurrentPriority(layoutPriority: layoutPriority)
        
        ListFactory_GroupsA.flexerGroupListReset()
        ListFactory_GroupsA.pieceGroupListReset()
        ListFactory_GroupsA.nodeGroupListReset()
        ListFactory_GroupsA.sectionListReset()
        
        let flexerGroups = groupData.flexerGroups
        let pieceGroups = groupData.pieceGroups
        let nodeGroups = groupData.nodeGroups
        let sections = groupData.sections
        
        for pieceGroup in pieceGroups {
            ListFactory_GroupsA.pieceGroupListAdd(pieceGroup: pieceGroup)
            pieceGroup.isLockedAtCurrentPriority = false
            
            pieceGroup.isMono = (pieceGroup.linkedList.count <= 1)
            pieceGroup.isActiveAtCurrentPriority = pieceGroup.matchesPriority(layoutPriority: layoutPriority)
            
        }
        
        for flexerGroup in flexerGroups {
            ListFactory_GroupsA.flexerGroupListAdd(flexerGroup: flexerGroup)
            flexerGroup.isLockedAtCurrentPriority = false
            
            flexerGroup.isMono = (flexerGroup.linkedList.count <= 1)
            flexerGroup.isActiveAtCurrentPriority = flexerGroup.matchesPriority(layoutPriority: layoutPriority)
            
        }
        
        for nodeGroup in nodeGroups {
            ListFactory_GroupsA.nodeGroupListAdd(nodeGroup: nodeGroup)
            nodeGroup.isLockedAtCurrentPriority = false
            
            nodeGroup.isMono = (nodeGroup.linkedList.count <= 1)
            nodeGroup.isActiveAtCurrentPriority = nodeGroup.matchesPriority(layoutPriority: layoutPriority)
        }
        
        for section in groupData.sections {
            ListFactory_GroupsA.sectionListAdd(section: section)
            section.isLockedAtCurrentPriority = false
        }
    }
    
    public static func prepare_intelligent(groupData: SkeletonLayoutGroupDataExploded, layoutPriority: LayoutPriority) {
        prepare_naive(groupData: groupData,
                      layoutPriority: layoutPriority)
    }
    
    
    
}
